package br.edu.fatecpg.calculadoraprimeiraleideohm

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import model.OhmCalculator
import util.InputValidator

class MainActivity : AppCompatActivity() {

    private lateinit var etVoltage: EditText
    private lateinit var etResistance: EditText
    private lateinit var etCurrent: EditText
    private lateinit var btnCalculate: Button
    private lateinit var tvResult: TextView

    private val calculator = OhmCalculator()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etVoltage = findViewById(R.id.etVoltage)
        etResistance = findViewById(R.id.etResistance)
        etCurrent = findViewById(R.id.etCurrent)
        btnCalculate = findViewById(R.id.btnCalculate)
        tvResult = findViewById(R.id.tvResult)

        btnCalculate.setOnClickListener { calculate() }
    }

    private fun calculate() {
        val voltage = etVoltage.text.toString()
        val resistance = etResistance.text.toString()
        val current = etCurrent.text.toString()

        when {
            InputValidator.isValidDouble(voltage) && InputValidator.isValidNonZero(resistance) -> {
                val result = calculator.calculateCurrent(voltage.toDouble(), resistance.toDouble())
                tvResult.text = "Corrente: ${result}A"
            }
            InputValidator.isValidDouble(voltage) && InputValidator.isValidNonZero(current) -> {
                val result = calculator.calculateResistance(voltage.toDouble(), current.toDouble())
                tvResult.text = "Resistência: ${result}Ω"
            }
            InputValidator.isValidDouble(resistance) && InputValidator.isValidNonZero(current) -> {
                val result = calculator.calculateVoltage(resistance.toDouble(), current.toDouble())
                tvResult.text = "Tensão: ${result}V"
            }
            else -> {
                tvResult.text = "Por favor, insira valores válidos."
            }
        }
    }
}
