package util

object InputValidator {
    fun isValidDouble(value: String?): Boolean {
        return value?.toDoubleOrNull() != null
    }

    fun isValidNonZero(value: String?): Boolean {
        return value?.toDoubleOrNull()?.let { it != 0.0 } ?: false
    }
}