package model

class OhmCalculator {
    fun calculateCurrent(voltage: Double, resistance: Double): Double {
        return voltage / resistance
    }

    fun calculateResistance(voltage: Double, current: Double): Double {
        return voltage / current
    }

    fun calculateVoltage(resistance: Double, current: Double): Double {
        return resistance * current
    }
}