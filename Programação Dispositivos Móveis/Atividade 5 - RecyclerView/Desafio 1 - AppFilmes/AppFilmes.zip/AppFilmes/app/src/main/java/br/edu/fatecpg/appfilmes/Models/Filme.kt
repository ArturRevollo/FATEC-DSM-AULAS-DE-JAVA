package br.edu.fatecpg.appfilmes.Models

data class Filme(
    val Titulo:String = "",
    val Diretor:String = ""
)
