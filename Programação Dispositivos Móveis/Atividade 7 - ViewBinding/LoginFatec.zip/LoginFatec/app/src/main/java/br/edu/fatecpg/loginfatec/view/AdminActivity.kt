package br.edu.fatecpg.loginfatec.view

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import br.edu.fatecpg.loginfatec.R
import br.edu.fatecpg.loginfatec.adapter.UsuarioAdapter
import br.edu.fatecpg.loginfatec.viewmodel.LoginViewModel

class AdminActivity : AppCompatActivity() {
    private val viewModel: LoginViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)

        val recyclerView: RecyclerView = findViewById(R.id.recyclerViewUsuarios)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val usuarios = viewModel.getUsuarios()
        val adapter = UsuarioAdapter(usuarios)
        recyclerView.adapter = adapter
    }
}
